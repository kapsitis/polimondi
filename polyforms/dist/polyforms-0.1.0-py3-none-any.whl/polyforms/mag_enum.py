from .NSturis import findAllSolutions
from .NSturis import Format
from .NSturis import FileWriter

def list_iamonds(perm):
    findAllSolutions(perm, Format.COMPACT, 'poly_{}_{}.txt'.format(len(perm), perm))


